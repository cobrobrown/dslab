import numpy as np

def foo(a):
    return a+2